import CartContent from '@/components/ecom/Cart';

export function Cart() {
  return (
    <div className="wix-verticals-container">
      <CartContent />
    </div>
  );
}
